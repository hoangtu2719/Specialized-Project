﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Gymer.Areas.ADMIN.Controllers
{
    public class TrangChuController : Controller
    {
        // GET: ADMIN/TrangChu
        public ActionResult Index()
        {
            return View();
        }
    }
}